Required Packages:
pdflatex (texlive-full)
octave
epstool
xfig
make

To compile, run 'make'
